-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2018 at 02:58 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newsbeat`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL,
  `article_title` varchar(155) NOT NULL,
  `article_thumbnail` varchar(100) NOT NULL,
  `article_summary` text,
  `article_full` text NOT NULL,
  `publish_datetime` datetime NOT NULL,
  `author_id` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`article_id`, `article_title`, `article_thumbnail`, `article_summary`, `article_full`, `publish_datetime`, `author_id`, `deleted`) VALUES
(1, 'as', 'noimage.jpeg', 'as', '<p>as</p>', '2018-01-16 17:24:49', 2, 0),
(2, 'asd', 'noimage.jpeg', 'asd', '<p>asd</p>', '2018-01-16 18:44:56', 2, 0),
(3, 'Ang Gulugod ng Epektibong Pamamahayag', '1516175654.jpg', 'Editoryal ng Pre-NSPC 2018 tungkol sa Regional Association of Elementary School Paper Advisers Association (RAESPA) at Regional Secondary School Paper Advisers Association (RASSPA).', '<div data-block=\"true\" data-editor=\"fjrf8\" data-offset-key=\"5njhq-0-0\" style=\"box-sizing: border-box; color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">\r\n  <div data-offset-key=\"5njhq-0-0\" class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\" style=\"box-sizing: border-box;\"><span data-offset-key=\"5njhq-0-0\" style=\"box-sizing: border-box;\">Kahit kailanman ay hindi maipagkukubling ang mithiin ng Regional Association of Elementary School Paper Advisers (RAESPA) at Regional Secondary School Paper Advisers Association(RASSPA) ang siyang nagsisilbing gabay ng mga pampaaralang mamamahayag upang ipagpatuloy ang pagsisiwalat ng impormasyong walang bahid ng kasinungalingan.</span></div>\r\n</div>\r\n<div data-block=\"true\" data-editor=\"fjrf8\" data-offset-key=\"1grg0-0-0\" style=\"box-sizing: border-box; color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">\r\n  <div data-offset-key=\"1grg0-0-0\" class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\" style=\"box-sizing: border-box;\"><span data-offset-key=\"1grg0-0-0\" style=\"box-sizing: border-box;\">Ang organisasyong binubuo ng mga tagapayo ng mga pampaaralang mamamahayag mula sa iba’t ibang dibisyon na nagsilbing daan upang lubos na paigtingin ang pagpapatupad ng Batas Republika 7079 o mas kilala bilang Campus Journalism Act of 1991. Sila ang dahilan kung bakit nagkakaroon ng taunang pambansa at panrehiyong press conferences. Sa paraang ito, patuloy na nahuhulma ang tatak ng pagkakakilanlan ng bawat manunulat at gayundin nahahasa ang kanilang kakayahan sa iba’t ibang paghahanda na isiniasagawa. Dahil sa adhikain ng parehong organisasyon, sa taong 2014 at 2016 kinilala ito bilang opisyal na samahang nabigyan ng sertipiko ng pagkilala mula sa Security Commision (SEC). </span></div>\r\n</div>\r\n<div data-block=\"true\" data-editor=\"fjrf8\" data-offset-key=\"5u54m-0-0\" style=\"box-sizing: border-box; color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">\r\n  <div data-offset-key=\"5u54m-0-0\" class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\" style=\"box-sizing: border-box;\"><span data-offset-key=\"5u54m-0-0\" style=\"box-sizing: border-box;\">Bilang isang ganap na kinikilalang organisasyon, nagkaroon ito ng sariling pondo na kung saan malaya itong nagagamit ng dalawang samahan para sa patuloy na pagpapalawak ng mga programang hahasa sa bawat manunulat.</span></div>\r\n</div>\r\n<div data-block=\"true\" data-editor=\"fjrf8\" data-offset-key=\"56er5-0-0\" style=\"box-sizing: border-box; color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">\r\n  <div data-offset-key=\"56er5-0-0\" class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\" style=\"box-sizing: border-box;\"><span data-offset-key=\"56er5-0-0\" style=\"box-sizing: border-box;\">Bagamat kadalasan ang mga  pampaaralang mamamahayag lang ang nabibigyang pansin ng karamihan pagdating sa kompetisyon, nararapat din lamang na kilalanin ang mga taong nasa likod ng bawat mamamahayag na ito na siyang gumagabay sa kanila sa bawat hakbang. Ang mga programang inilunsad ng RAESPA at RSSPAA ang naging pangunahing pundasyon ng mahusay na performans ng bawat rehiyon na nagiiwan ng tatak na siyang kahit kailanma’y hindi magagaya ng kahit ninuman. </span></div>\r\n</div>\r\n<p><br /></p>', '2018-01-17 15:54:14', 2, 0),
(4, 'DepEd adopts Philippine Professional Standard for Teachers to further improve educators’ qualification skills', 'noimage.jpeg', NULL, '<div data-block=\"true\" data-editor=\"cp91t\" data-offset-key=\"9cn52-0-0\" style=\"box-sizing: border-box; color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">\r\n  <div data-offset-key=\"9cn52-0-0\" class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\" style=\"box-sizing: border-box;\"><span data-offset-key=\"9cn52-0-0\" style=\"box-sizing: border-box;\"> </span><span data-offset-key=\"9cn52-0-1\" style=\"box-sizing: border-box; font-style: italic;\">PASIG CITY, January 16, 2018</span><span data-offset-key=\"9cn52-0-2\" style=\"box-sizing: border-box;\"> – Recognizing the importance of professionalizing standards for teachers and for their continuous development, the Department of Education (DepEd), through the Teacher Education Council (TEC), adopted the Philippine Professional Standards for Teachers (PPST).\r\n \r\nIn DepEd Order No. 42, series 2017 or the National Adoption and Implementation of the Philippine Professional Standards for Teachers, Education Secretary Leonor Magtolis Briones stated that the new set of standards for teachers is propelled by the introduction of national and international frameworks, such as the K to 12 program and ASEAN integration.\r\n \r\nThe PPST outlines the required skills and competencies of quality teachers, enabling them to cope with the emerging global frameworks.\r\n \r\nThe PPST basically aims to: 1) set the clear expectations of teachers along well-defined career stages of professional development from beginning to distinguished practice; 2) engage teachers to actively embrace a continuing effort in attaining proficiency; and 3) apply a uniform measure to assess teacher performance, identify needs, and provide support for professional development.\r\n \r\nBriones pointed out that the PPST will be the basis for all learning and development programs for teachers to ensure that they are properly equipped to effectively implement the K to 12.\r\n \r\n</span><span data-offset-key=\"9cn52-0-3\" style=\"box-sizing: border-box; font-weight: bold;\">Teacher quality for the 21st century</span><span data-offset-key=\"9cn52-0-4\" style=\"box-sizing: border-box;\">\r\nThe PPST targets to produce better teachers in the country by improving their qualifications skills and by increasing their levels of knowledge, practice and professional engagement.\r\n \r\nThe six modules of the PPST are the following: 1) The Department of Education; 2) The Filipino Teacher; 3) The K to 12 curriculum; 4) The Teaching Process; 5) the Learning Process; and 6) The School and Community Linkages.&nbsp; These are all anchored on the seven domains that quality teachers should exhibit including: 1) Content Knowledge and Pedagogy; 2) Learning Environment; 3) Diversity of learners; 4) Curriculum and Planning; 5) Assessment and Reporting; 6) Community Linkages and Professional Engagement; and 7) Personal Growth and Professional Development.\r\n \r\n</span><span data-offset-key=\"9cn52-0-5\" style=\"box-sizing: border-box; font-weight: bold;\">Career stages</span><span data-offset-key=\"9cn52-0-6\" style=\"box-sizing: border-box;\">\r\nAnchored on the principle of lifelong learning, the set of professional standards for teachers articulates their developmental progression.\r\n \r\nCareer Stage 1 or Beginning Teachers have gained the qualifications for entry into teaching position; Career Stage 2 or Proficient Teachers are professionally independent in the application of skills vital to the teaching and learning process; Career Stage 3 or Highly Proficient Teachers consistently display a high level of performance in their teaching practice; and Career Stage 4 or Distinguished Teachers exhibit the highest standard of teaching practice in accordance to global best practice.\r\n \r\nThe regional offices are set to orient their respective schools divisions on the PPST, including the monitoring and evaluation of its implementation. The school divisions will cascade it to schools districts and schools.\r\n \r\n</span><span data-offset-key=\"9cn52-0-7\" style=\"box-sizing: border-box; font-weight: bold;\">2017 PPST activities</span><span data-offset-key=\"9cn52-0-8\" style=\"box-sizing: border-box;\"> \r\nDepEd, through the Teacher Education Council (TEC) headed by Director Runvi Manguerra, has initiated the PPST workshops on Module Development, Enhancement and Validation attended by curriculum specialists, school heads, and other stakeholders. A workshop on the Development of Implementing Guidelines for PPST was also conducted in coordination with the Research Center for Teacher Quality (RCTQ), and attended by DepEd Regional Directors and officers of Basic Education Sector Transformation (BEST) program.\r\n \r\nTEC also spearheaded the PPST National Roll-Out, as well as the Teacher Induction Program (TIP) National Orientation of Trainers in three clusters – Luzon, Visayas, and Mindanao, which was participated by DepEd Directors, Schools Division Superintendents, chiefs, district supervisors, principals, education program specialists, master teachers, and RCTQ officials. This was followed by TIP module review workshops and module pre-finalization workshops.\r\n \r\nThe concept of the PPST was first introduced during the First National Assembly of Education Leaders held at PICC, Pasay City, and attended by 3,800 education managers nationwide. It was formally launched during the World Teachers’ Day (WTD) celebration held in Legazpi City that was attended by 6,000 teachers across the country.\r\n \r\n</span><span data-offset-key=\"9cn52-0-9\" style=\"box-sizing: border-box; font-weight: bold;\">END</span><span data-offset-key=\"9cn52-0-10\" style=\"box-sizing: border-box;\"> </span></div>\r\n</div>\r\n<div data-block=\"true\" data-editor=\"cp91t\" data-offset-key=\"21e2o-0-0\" style=\"box-sizing: border-box; color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">\r\n  <div data-offset-key=\"21e2o-0-0\" class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\" style=\"box-sizing: border-box;\"><span data-offset-key=\"21e2o-0-0\" style=\"box-sizing: border-box;\"><br data-text=\"true\" style=\"box-sizing: border-box;\" /></span></div>\r\n</div>\r\n<div data-block=\"true\" data-editor=\"cp91t\" data-offset-key=\"1oc0a-0-0\" style=\"box-sizing: border-box; color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">\r\n  <div data-offset-key=\"1oc0a-0-0\" class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\" style=\"box-sizing: border-box;\"><span data-offset-key=\"1oc0a-0-0\" style=\"box-sizing: border-box; font-weight: bold;\">Source:</span><span data-offset-key=\"1oc0a-0-1\" style=\"box-sizing: border-box;\"> </span><a href=\"http://www.deped.gov.ph/press-releases/deped-adopts-philippine-professional-standard-teachers-further-improve-educators%E2%80%99\" style=\"box-sizing: border-box; background: transparent; color: rgb(231, 98, 41); transition-duration: 0.2s; transition-timing-function: ease; transition-delay: initial; transition-property: color;\"><span data-offset-key=\"1oc0a-1-0\" style=\"box-sizing: border-box;\">http://www.deped.gov.ph/press-releases/deped-adopts-philippine-professional-standard-teachers-further-improve-educators%E2%80%99</span></a></div>\r\n</div>\r\n<div data-block=\"true\" data-editor=\"cp91t\" data-offset-key=\"4bsqj-0-0\" style=\"box-sizing: border-box; color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">\r\n  <div data-offset-key=\"4bsqj-0-0\" class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\" style=\"box-sizing: border-box;\"><span data-offset-key=\"4bsqj-0-0\" style=\"box-sizing: border-box;\"><br data-text=\"true\" style=\"box-sizing: border-box;\" /></span></div>\r\n</div>\r\n<div data-block=\"true\" data-editor=\"cp91t\" data-offset-key=\"66ute-0-0\" style=\"box-sizing: border-box; color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">\r\n  <div data-offset-key=\"66ute-0-0\" class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\" style=\"box-sizing: border-box;\"><span data-offset-key=\"66ute-0-0\" style=\"box-sizing: border-box;\"> </span></div>\r\n</div>\r\n<div data-block=\"true\" data-editor=\"cp91t\" data-offset-key=\"9q1jn-0-0\" style=\"box-sizing: border-box; color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">\r\n  <div data-offset-key=\"9q1jn-0-0\" class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\" style=\"box-sizing: border-box;\"><span data-offset-key=\"9q1jn-0-0\" style=\"box-sizing: border-box; font-weight: bold;\">Official DepEd Website: </span><a href=\"http://www.deped.gov.ph/\" style=\"box-sizing: border-box; background: transparent; color: rgb(231, 98, 41); transition-duration: 0.2s; transition-timing-function: ease; transition-delay: initial; transition-property: color;\"><span data-offset-key=\"9q1jn-1-0\" style=\"box-sizing: border-box;\">http://www.deped.gov.ph</span></a><span data-offset-key=\"9q1jn-2-0\" style=\"box-sizing: border-box;\"> \r\n</span><span data-offset-key=\"9q1jn-2-1\" style=\"box-sizing: border-box; font-weight: bold;\">Like us on Facebook:</span><span data-offset-key=\"9q1jn-2-2\" style=\"box-sizing: border-box;\"> </span><a href=\"http://www.facebook.com/DepEd.Philippines\" style=\"box-sizing: border-box; background: transparent; color: rgb(231, 98, 41); transition-duration: 0.2s; transition-timing-function: ease; transition-delay: initial; transition-property: color;\"><span data-offset-key=\"9q1jn-3-0\" style=\"box-sizing: border-box;\">facebook.com/DepEd.Philippines</span></a><span data-offset-key=\"9q1jn-4-0\" style=\"box-sizing: border-box;\"> \r\n</span><span data-offset-key=\"9q1jn-4-1\" style=\"box-sizing: border-box; font-weight: bold;\">Follow us on Twitter:</span><span data-offset-key=\"9q1jn-4-2\" style=\"box-sizing: border-box;\"> </span><a href=\"https://twitter.com/DepEd_PH\" style=\"box-sizing: border-box; background: transparent; color: rgb(231, 98, 41); transition-duration: 0.2s; transition-timing-function: ease; transition-delay: initial; transition-property: color;\"><span data-offset-key=\"9q1jn-5-0\" style=\"box-sizing: border-box;\">@DepEd_PH</span></a><span data-offset-key=\"9q1jn-6-0\" style=\"box-sizing: border-box;\"> </span></div>\r\n</div>\r\n<p><br /></p>', '2018-01-17 15:59:44', 2, 0),
(5, '7 dating RAESPA, RSSPAA opisyales, binigyang parangal', '1516183224.jpg', 'Pitong palabas na opisyales ng Regional Association of Elementary School Paper Advisers (RAESPA) at Regional Secondary School Paper Advisers Association (RSSPAA) ang binigyang parangal sa Pre-NSPC 2018 Intensive Training ng Rehiyon Otso. | Candice Docos', '<p><span style=\"text-decoration: underline;\"></span><span style=\"color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">Apat na opisyales ng Regional Association of Elementary School Paper Advisers Association (RAESPA) at tatlo naman sa Regional Association of Secondary School Paper Advisers Association (RSSPAA) ang gagawaran ng pagkilala bilang mga papalabas na nanilbihan sa organisasyon sa Pre-NSPC mamayang hapon.</span></p>\r\n<p><br /></p>\r\n<div data-block=\"true\" data-editor=\"7gg1u\" data-offset-key=\"kl62-0-0\" style=\"box-sizing: border-box; color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">\r\n  <div data-offset-key=\"kl62-0-0\" class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\" style=\"box-sizing: border-box;\"><span data-offset-key=\"kl62-0-0\" style=\"box-sizing: border-box;\">Ang mga nasabing opisyales ng RAESPA ay sina Mark Salas, Dating Pangulo; Mailyn Labine, Pangalawang Pangulo ng Samar; Hilario Genovia, Pangalawang Pangulo ng Leyte; at Fhelda Guitoria, Tagasuri habang sa RSSPA naman ay sina Riche Gonzaga, Pangalawang Pangulo; Petronio Ordavisa Jr., Tagasuri; at Dean Ric Endriano, Editors Guild Adviser. </span></div>\r\n</div>\r\n<div data-block=\"true\" data-editor=\"7gg1u\" data-offset-key=\"9h0u1-0-0\" style=\"box-sizing: border-box; color: rgb(76, 76, 73); font-family: \'Droid Serif\', \'Helvetica Neue\', georgia, times, serif; font-size: 18px; white-space: pre-wrap; background-color: rgb(249, 249, 249);\">\r\n  <div data-offset-key=\"9h0u1-0-0\" class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\" style=\"box-sizing: border-box;\"><span data-offset-key=\"9h0u1-0-0\" style=\"box-sizing: border-box;\">Narito ang mga </span><a href=\"https://x.rappler.com/x/rendzborg-bautista-nspc2017-angsirang/%3Ciframe%20src=%22https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fphoto.php%3Ffbid%3D308519609659170%26set%3Da.127699401074526.1073741828.100015033999500%26type%3D3&amp;width=500%22%20width=%22500%22%20height=%22570%22%20style=%22border:none;overflow:hidden%22%20scrolling=%22no%22%20frameborder=%220%22%20allowTransparency=%22true%22%3E%3C/iframe%3E\" style=\"box-sizing: border-box; background: transparent; color: rgb(231, 98, 41); transition-duration: 0.2s; transition-timing-function: ease; transition-delay: initial; transition-property: color;\"><span data-offset-key=\"9h0u1-1-0\" style=\"box-sizing: border-box;\">bagong halal sa RAESPA</span></a><span data-offset-key=\"9h0u1-2-0\" style=\"box-sizing: border-box;\">: Harold Naputo, Pangulo; Jeffrey Cawaling, Pangalawang Pangulo; Josephine Contapay, Kalihim; Venecia Palencia, Ingat-yaman ; Lourdes Alote, Tagasuri; Raymund Remandaban, Tagasuri, Efren Superable, PIO; Ana Belle, Business Manager at John Michael Jalayjay, Editors Guild Adviser. </span></div>\r\n</div>\r\n<p><br /></p>', '2018-01-17 18:00:24', 3, 0),
(6, 'asd', '1516340795.jpg', 'asd', '<p>asd</p>', '2018-01-19 13:46:35', 6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE `author` (
  `author_id` int(11) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `display_name` varchar(20) NOT NULL,
  `description` text,
  `prof_pic` varchar(100) DEFAULT NULL,
  `cover_pic` varchar(100) DEFAULT NULL,
  `url` varchar(10) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`author_id`, `first_name`, `last_name`, `display_name`, `description`, `prof_pic`, `cover_pic`, `url`, `deleted`) VALUES
(1, 'John Louise', 'Lazaro', 'LOLO', NULL, 'profileicon.jpg', NULL, NULL, 0),
(2, 'John Louise', 'Lazaro', 'LOLO', NULL, 'profileicon.jpg', NULL, NULL, 0),
(3, 'lolo', 'lolo', 'lolo', NULL, 'profileicon.jpg', NULL, NULL, 0),
(4, 'Louise Lazaro', 'llala', 'lalal', NULL, 'profileicon.jpg', NULL, NULL, 0),
(5, 'as', 'as', 'as', NULL, 'profileicon.jpg', NULL, NULL, 0),
(6, 'qwe', 'qwe', 'qwe', NULL, '1516340657.jpg', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `remember_token`, `author_id`, `deleted`) VALUES
(1, 'admin', '$2y$10$yE98vDMxsSsRSNev1/zy.uWIpWSHzDiMo159lbty/AwY/MWKjnEdy', '', NULL, 0),
(2, 'lazaro101', '$2y$10$dJvhowOQZnI6V2HrvDlW/eoJ8/GriPtB83MJKly3P9eMqN78dZl4i', 'CxAOINeAHo7XueHCqrB1wXnEq2PJlJOYMGQ5iJCKB6iSgRxSIaO9Rq2IX2yL', 2, 0),
(3, 'lolo', '$2y$10$Jke2me2hip49fT9QCruPOOOmyFFYBy95qLiKdZRF.W6Tgtx4jUI5K', 'ygTcHW7alxnvaF21YM1qkzjkZyOt5rLGtz7a7mpbzXQWdqmRr3adITxKMDf5', 3, 0),
(4, 'popo', '$2y$10$ZVq3tRlpOJwHWoZ/GL8v7O8OHi4PLutQNHEIZMwcvdRUmRst1oI.G', 'bUriqZcIf2tq92CGQVBCoThXpnKnuKM9KxLzpn28uyWLKMjM7eHsTm7XSE63', 4, 0),
(5, 'as', '$2y$10$/UF4WhwBT3wHiMyC.JJSnezYFIHA2k5TCSaiJbMmthLsno9ymBiMi', NULL, 5, 0),
(6, 'qwe', '$2y$10$v8mEE6RCmgIX1FFcschc4.QyCVODe63l.d0vCntgchsrpSJ37DgG2', NULL, 6, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`article_id`),
  ADD KEY `author_id` (`author_id`);

--
-- Indexes for table `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`author_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`author_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `article_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `author`
--
ALTER TABLE `author`
  MODIFY `author_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
